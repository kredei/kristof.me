// Kristof Redei, COMP 163 Final Project
#ifndef HULLGRAPH_H
#define HULLGRAPH_H

#include "hGraph.h"

hGraph* hullGraph(const list<point*>& points, bool lower, window& W);
hGraph* bridge(hGraph* left, hGraph* right, bool lower, window& W);
int tangentLineLeft(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode);
int tangentLineRight(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode);
int ltangentLineLeft(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode);
int ltangentLineRight(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode);
int pointX(point* const &v1, point* const &v2);

#endif /* HULLGRAPH_H */