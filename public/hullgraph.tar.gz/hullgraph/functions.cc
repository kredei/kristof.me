// Functions to compute the hull graph of a point set.
// Kristof Redei, COMP 163 Final Project

#include <iostream>
#include <LEDA/graph.h>
#include <LEDA/point.h>
#include <LEDA/list.h>
#include <LEDA/d_array.h>
#include <LEDA/sortseq.h>
#include <LEDA/line.h>
#include <LEDA/window.h>
#include <LEDA/node_map.h>

#include "functions.h"
#include "hGraph.h"

using namespace std;

// Find the hull graph given a list of points.
hGraph* hullGraph(const list<point*>& points, bool lower, window& W) {

  hGraph* hg = new hGraph();
  hg->clear();
 
  // Base case
  if (points.size() == 1) {
    node newNode = hg->new_node(points.inf(points.first()));
    hg->leftLists[newNode] = sortseq<double,node>();
    hg->rightLists[newNode] = sortseq<double,node>();
    return hg;  
  }
  
  // Otherwise, split into left and right sets, and merge their hull graphs.
  list<point*> leftSet;
  list<point*> rightSet;
  int i = 0;
  
  while (i < points.size()) {
    if (i < int(points.size() / 2)) {
      leftSet.append(points.inf(points.get_item(i)));
    }
    else {
      rightSet.append(points.inf(points.get_item(i)));
    }
    i++;
  }
  return bridge(hullGraph(leftSet, lower, W), hullGraph(rightSet, lower,W), lower, W);

}

// Find the bridge between two hull graphs and merge them.
hGraph* bridge(hGraph* left, hGraph* right, bool lower, window& W) {
  
  node leftNode;
  node rightNode;
  node n; node m; node l; node r;
  double x; double y; int button; 
  
  // Start search for tangent line at rightmost point in left set, and leftmost point in right set.
  leftNode = left->choose_node();
  rightNode = right->choose_node();
  
  forall_nodes(l,*left) {
    if (left->inf(l)->xcoord() > left->inf(leftNode)->xcoord()) {
      leftNode = l;
    }
  }
  
  forall_nodes(r,*right) {
    if (right->inf(r)->xcoord() < right->inf(rightNode)->xcoord()) {
      rightNode = r;
    }
  }

 if(lower) {
   // Stop when we find a tangent line that supports both subsets.  
   while (!(ltangentLineLeft(*left, *right, leftNode, rightNode) && ltangentLineRight(*left, *right, leftNode, rightNode))) {
 
    // Move the left point counterclockwise until we find a line supporting the left set.
   while (!ltangentLineLeft(*left, *right, leftNode, rightNode)) {
     if (left->leftLists[leftNode].max_item() != nil) {
       leftNode = left->leftLists[leftNode].inf(left->leftLists[leftNode].max_item());
       if (left->number_of_nodes() == 4) printf("movedleft\n");printf("%d right neighbors\n",right->rightLists[rightNode].size());

     } else break;
   }
    
    // Move the right point clockwise until we find a line supporting the right set.
   while (!ltangentLineRight(*left, *right, leftNode, rightNode)) {
     if (right->rightLists[rightNode].min_item() != nil) {
       rightNode = right->rightLists[rightNode].inf(right->rightLists[rightNode].min_item());
       if (left->number_of_nodes() == 4) printf("movedright\n");
     } else { printf("%d right neighbors\n",right->rightLists[rightNode].size()); break; }
   }

   }
 } else {
   
  // Stop when we find a tangent line that supports both subsets.  
  while (!(tangentLineLeft(*left, *right, leftNode, rightNode) && tangentLineRight(*left, *right, leftNode, rightNode))) {
 
    // Move the left point counterclockwise until we find a line supporting the left set.
    while (!tangentLineLeft(*left, *right, leftNode, rightNode)) {
      if (left->leftLists[leftNode].max_item() != nil) {
	if (!lower) leftNode = left->leftLists[leftNode].inf(left->leftLists[leftNode].min_item());
	else leftNode = left->leftLists[leftNode].inf(left->leftLists[leftNode].max_item());
      } else break;
    }
    
    // Move the right point clockwise until we find a line supporting the right set.
    while (!tangentLineRight(*left, *right, leftNode, rightNode)) {
      if (right->rightLists[rightNode].max_item() != nil) {
        if (!lower) rightNode = right->rightLists[rightNode].inf(right->rightLists[rightNode].max_item());
	else rightNode = right->rightLists[rightNode].inf(right->rightLists[rightNode].min_item());
      } else break;
    }

  }
  
 }
    
  
  // Merge the two sets and add the bridge.
  node_map<node> pairs;
  
  m = left->new_node(left->last_node(),right->inf(rightNode),LEDA::after);
  pairs[rightNode] = m;
  
  forall_nodes (n, *right) {
    if (right->inf(n) != right->inf(rightNode)) {
    node o = left->new_node(left->last_node(),right->inf(n),LEDA::after);
    pairs[n] = o;
    }
  }
  
  left->leftLists[m].insert(line(*left->inf(leftNode),*left->inf(m)).slope(), leftNode);
  if (lower) W.draw_segment(left->inf(leftNode)->xcoord(),left->inf(leftNode)->ycoord(),left->inf(m)->xcoord(),left->inf(m)->ycoord(),blue);
  else W.draw_segment(left->inf(leftNode)->xcoord(),left->inf(leftNode)->ycoord(),left->inf(m)->xcoord(),left->inf(m)->ycoord(),red);
  left->rightLists[leftNode].insert(line(*left->inf(leftNode),*left->inf(m)).slope(), m);
  
  forall_nodes (n, *right) {
    seq_item i = right->rightLists[n].min_item();
    
    while (i != nil) {
      left->rightLists[pairs[n]].insert(right->rightLists[n].key(i),pairs[right->rightLists[n].inf(i)]);
      i = right->rightLists[n].succ(i);
    }

    i = right->leftLists[n].min_item();
    
    while (i != nil) {
      left->leftLists[pairs[n]].insert(right->leftLists[n].key(i),pairs[right->leftLists[n].inf(i)]);
      i = right->leftLists[n].succ(i);
    } 
  }

  while (button = W.read_mouse(x, y)){ if (button == 4) break; }
  
  return left;

}

// Determine whether the line given by leftNode and rightNode supports the left set.
int tangentLineLeft(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode) {
  
  line s = line(*left.inf(leftNode),*right.inf(rightNode));
  
  seq_item leftpredseq = left.leftLists[leftNode].min_item();
  seq_item leftsuccseq = left.rightLists[leftNode].max_item();
  
  node leftprednode;
  node leftsuccnode;
  
  if (leftpredseq != nil) { leftprednode = left.leftLists[leftNode].inf(leftpredseq); }
  if (leftsuccseq != nil) { leftsuccnode = left.rightLists[leftNode].inf(leftsuccseq);}

  // Test both neighbors of leftNode.
  if (leftpredseq != nil && 
      s.slope() > line(*left.inf(leftprednode),*right.inf(rightNode)).slope()) { return false; }
  if (leftsuccseq != nil && 
      s.slope() > line(*left.inf(leftsuccnode),*right.inf(rightNode)).slope()) { return false; }
  
  return true;
  
}

// Determine whether the line given by leftNode and rightNode supports the right set.
int tangentLineRight(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode) {
  
  line s = line(*left.inf(leftNode),*right.inf(rightNode));
  
  seq_item rightpredseq = right.leftLists[rightNode].min_item();
  seq_item rightsuccseq = right.rightLists[rightNode].max_item();
  
  node rightprednode;
  node rightsuccnode;

  if (rightpredseq != nil) { rightprednode = right.leftLists[rightNode].inf(rightpredseq); }
  if (rightsuccseq != nil) { rightsuccnode = right.rightLists[rightNode].inf(rightsuccseq);}
  
  // Test both neighbors of rightNode.
  if (rightpredseq != nil && 
      s.slope() < line(*left.inf(leftNode),*right.inf(rightprednode)).slope()) { return false; }
  if (rightsuccseq != nil && 
      s.slope() < line(*left.inf(leftNode),*right.inf(rightsuccnode)).slope()) { return false; }
  
  return true;
  
}

// Determine whether the line given by leftNode and rightNode supports the left set.
int ltangentLineLeft(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode) {
  
  line s = line(*left.inf(leftNode),*right.inf(rightNode));
  
  seq_item leftpredseq = left.leftLists[leftNode].max_item();
  seq_item leftsuccseq = left.rightLists[leftNode].min_item();
  
  node leftprednode;
  node leftsuccnode;
  
  if (leftpredseq != nil) { leftprednode = left.leftLists[leftNode].inf(leftpredseq); }
  if (leftsuccseq != nil) { leftsuccnode = left.rightLists[leftNode].inf(leftsuccseq);}

  // Test both neighbors of leftNode.
  if (leftpredseq != nil && 
      s.slope() < line(*left.inf(leftprednode),*right.inf(rightNode)).slope()) { return false; }
  if (leftsuccseq != nil && 
      s.slope() < line(*left.inf(leftsuccnode),*right.inf(rightNode)).slope()) { return false; }
  
  return true;
  
}

// Determine whether the line given by leftNode and rightNode supports the right set.
int ltangentLineRight(const hGraph& left, const hGraph& right, const node& leftNode, const node& rightNode) {
  
  line s = line(*left.inf(leftNode),*right.inf(rightNode));
  
  seq_item rightpredseq = right.leftLists[rightNode].max_item();
  seq_item rightsuccseq = right.rightLists[rightNode].min_item();
  
  node rightprednode;
  node rightsuccnode;

  if (rightpredseq != nil) { rightprednode = right.leftLists[rightNode].inf(rightpredseq); }
  if (rightsuccseq != nil) { rightsuccnode = right.rightLists[rightNode].inf(rightsuccseq);}
  
  // Test both neighbors of rightNode.
  if (rightpredseq != nil && 
      s.slope() > line(*left.inf(leftNode),*right.inf(rightprednode)).slope()) { return false; }
  if (rightsuccseq != nil && 
      s.slope() > line(*left.inf(leftNode),*right.inf(rightsuccnode)).slope()) { return false; }
  
  return true;
  
}

// Compare two points based on their x-coordinate.
int pointX(point* const &v1, point* const &v2) {
  
  if ((v1->xcoord() - v2->xcoord()) > 0) {
    return 1;
  }
  else if ((v1->xcoord() == v2->xcoord())) {
    return 0;
  }
  else return -1;

}