// Kristof Redei, COMP 163 Final Project

#include <iostream>
#include <LEDA/window.h>
#include <LEDA/graph.h>
#include <LEDA/point.h>
#include <LEDA/list.h>
#include <LEDA/sortseq.h>
#include <LEDA/color.h>

#include "hGraph.h"
#include "functions.h"

using namespace std;

window W("Hull Graph");
int button;

// Draw hull graph.
void drawGraph(hGraph& g, color c) {  
  node n; 
  node m;
  edge e;
  
  forall_nodes(n,g) {
    while (!g.rightLists[n].empty()) {
      seq_item m = g.rightLists[n].min_item();
      W.draw_segment(g.inf(n)->xcoord(),g.inf(n)->ycoord(),g.inf(g.rightLists[n].inf(m))->xcoord(),g.inf(g.rightLists[n].inf(m))->ycoord(),c);
      g.rightLists[n].del_item(m);
    }
  }

}

int main(){

  // Interface
  W.set_node_width(3);
  W.button("Upper Hull Graph",1);
  W.button("Lower Hull Graph",2);
  W.button("Step",4);
  W.button("Clear",3);
  W.button("Quit",0);
  W.display(350,150);
  
  double x; double y;
  list<point*> points;
  hGraph* hg;
 
  node_map< sortseq<double,edge> > listMap;
  
  while (button = W.read_mouse(x, y)){
    
    // Add a point to the screen.
    if (button == -1) {
      points.push(new point(x,y));
      W.draw_filled_node(x, y, blue);
    }
    
    // Display the upper hull graph of the current points.
    else if (button == 1) {
      points.sort(&pointX);
      hg = hullGraph(points, false, W);
      drawGraph(*hg, color("red"));
    }

    // Display the lower hull graph of the current points.
    else if (button == 2) {
      points.sort(&pointX);
      hg = hullGraph(points, true, W);
      drawGraph(*hg, color("blue"));
    }
    
    // Clear the screen.
    else if(button == 3) {
      W.clear();
      while(points.size()){
	point *d = points.pop(); 
	delete d;
      }
    }

  }
}
