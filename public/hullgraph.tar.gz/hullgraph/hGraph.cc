#include "hGraph.h"

hGraph::hGraph() {
  leftLists = node_map< sortseq<double,node> >();
  rightLists = node_map< sortseq<double,node> >();
}



