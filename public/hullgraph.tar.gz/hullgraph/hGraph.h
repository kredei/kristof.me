// Kristof Redei, COMP 163 Final Project
#ifndef HGRAPH_H
#define HGRAPH_H

#include <LEDA/graph.h>
#include <LEDA/sortseq.h>
#include <LEDA/point.h>

class hGraph : public GRAPH<point*,int> {

  public:
    hGraph();
    node_map< sortseq <double,node> > leftLists;
    node_map< sortseq <double,node> > rightLists;

};

#endif /* HGRAPH_H */